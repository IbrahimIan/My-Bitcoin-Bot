# MetaTrader 5 BTC/USD Trading Bot
# Based on the web application with similar functionality
# Compatible with MetaTrader 5 Python integration

import time
import datetime
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import os

# Import MetaTrader 5 module
try:
    import MetaTrader5 as mt5
except ImportError:
    print("MetaTrader5 package is not installed. Please install it using:")
    print("pip install MetaTrader5")
    exit(1)

class DataFetcher:
    """
    Class for fetching cryptocurrency price data from MT5
    """
    
    def __init__(self, symbol='BTCUSD'):
        """
        Initialize the data fetcher
        
        Args:
            symbol (str): Trading pair symbol (default: BTCUSD)
        """
        self.symbol = symbol
        
        # Initialize MT5 connection if not already initialized
        if not mt5.initialize():
            print("MetaTrader5 initialization failed")
            mt5.shutdown()
            exit(1)
    
    def get_current_price(self):
        """
        Get the current BTC/USD price
        
        Returns:
            float: Current price of BTC/USD
        """
        try:
            # Get the last tick
            last_tick = mt5.symbol_info_tick(self.symbol)
            if last_tick is None:
                raise Exception(f"Failed to get {self.symbol} tick")
            
            # Average of bid and ask
            return (last_tick.bid + last_tick.ask) / 2
        except Exception as e:
            print(f"Error fetching price: {str(e)}")
            # In case of error, try to re-initialize
            if not mt5.initialize():
                print("MetaTrader5 reinitialization failed")
            return None
    
    def get_historical_data(self, days=30, interval='1h'):
        """
        Get historical price data
        
        Args:
            days (int): Number of days of historical data to fetch
            interval (str): Time interval (1m, 5m, 15m, 1h, 4h, 1d)
            
        Returns:
            pd.DataFrame: DataFrame with timestamp and price columns
        """
        try:
            # Map string interval to MT5 timeframe constant
            timeframes = {
                '1m': mt5.TIMEFRAME_M1,
                '5m': mt5.TIMEFRAME_M5,
                '15m': mt5.TIMEFRAME_M15,
                '1h': mt5.TIMEFRAME_H1,
                '4h': mt5.TIMEFRAME_H4,
                '1d': mt5.TIMEFRAME_D1
            }
            
            if interval not in timeframes:
                interval = '1h'  # Default to 1 hour
            
            # Calculate start time
            end_time = datetime.now()
            start_time = end_time - timedelta(days=days)
            
            # Get OHLCV data
            rates = mt5.copy_rates_range(
                self.symbol,
                timeframes[interval],
                start_time,
                end_time
            )
            
            if rates is None or len(rates) == 0:
                print(f"Failed to get {self.symbol} historical data")
                return pd.DataFrame(columns=['timestamp', 'price'])
            
            # Convert to DataFrame
            df = pd.DataFrame(rates)
            
            # Convert time to datetime
            df['timestamp'] = pd.to_datetime(df['time'], unit='s')
            
            # Return only timestamp and close price
            return df[['timestamp', 'close']].rename(columns={'close': 'price'})
        
        except Exception as e:
            print(f"Error fetching historical data: {str(e)}")
            return pd.DataFrame(columns=['timestamp', 'price'])


class TradingStrategy:
    """Base class for trading strategies"""
    
    def __init__(self, name="Base Strategy"):
        """Initialize the strategy"""
        self.name = name
    
    def generate_signal(self, data):
        """
        Generate trading signals
        
        Args:
            data (pd.DataFrame): DataFrame with timestamp and price columns
            
        Returns:
            int: 1 for buy, -1 for sell, 0 for no action
        """
        # Base class doesn't implement strategy
        return 0
    
    def calculate_indicators(self, data):
        """
        Calculate technical indicators used by the strategy
        
        Args:
            data (pd.DataFrame): DataFrame with timestamp and price columns
            
        Returns:
            pd.DataFrame: DataFrame with added indicators
        """
        # Base class doesn't implement indicators
        return data


class MovingAverageCrossoverStrategy(TradingStrategy):
    """Moving Average Crossover Strategy"""
    
    def __init__(self, short_window=20, long_window=50):
        """
        Initialize the Moving Average Crossover Strategy
        
        Args:
            short_window (int): Short moving average window
            long_window (int): Long moving average window
        """
        super().__init__(name="MA Crossover")
        self.short_window = short_window
        self.long_window = long_window
    
    def calculate_indicators(self, data):
        """
        Calculate moving averages for the strategy
        
        Args:
            data (pd.DataFrame): DataFrame with timestamp and price columns
            
        Returns:
            pd.DataFrame: DataFrame with moving averages
        """
        if len(data) < self.long_window:
            # Not enough data to calculate indicators
            return data
        
        # Copy dataframe to avoid modifying original
        df = data.copy()
        
        # Calculate moving averages
        df['short_ma'] = df['price'].rolling(window=self.short_window).mean()
        df['long_ma'] = df['price'].rolling(window=self.long_window).mean()
        
        return df
    
    def generate_signal(self, data):
        """
        Generate trading signals based on moving average crossover
        
        Args:
            data (pd.DataFrame): DataFrame with timestamp and price columns
            
        Returns:
            int: 1 for buy, -1 for sell, 0 for no action
        """
        if len(data) < self.long_window:
            # Not enough data to generate signals
            return 0
        
        # Calculate indicators
        df = self.calculate_indicators(data)
        
        # Check for NaN values
        if df['short_ma'].iloc[-1] is None or np.isnan(df['short_ma'].iloc[-1]) or \
           df['long_ma'].iloc[-1] is None or np.isnan(df['long_ma'].iloc[-1]):
            return 0
        
        # Get the last two rows to detect crossover
        if len(df) < 2:
            return 0
        
        current = df.iloc[-1]
        previous = df.iloc[-2]
        
        # Check for crossover
        # Buy signal: short MA crosses above long MA
        if (previous['short_ma'] <= previous['long_ma']) and (current['short_ma'] > current['long_ma']):
            return 1
        
        # Sell signal: short MA crosses below long MA
        elif (previous['short_ma'] >= previous['long_ma']) and (current['short_ma'] < current['long_ma']):
            return -1
        
        # No signal
        return 0


class RSIStrategy(TradingStrategy):
    """RSI Strategy"""
    
    def __init__(self, rsi_period=14, overbought=70, oversold=30):
        """
        Initialize the RSI Strategy
        
        Args:
            rsi_period (int): Period for RSI calculation
            overbought (float): Overbought threshold
            oversold (float): Oversold threshold
        """
        super().__init__(name="RSI Strategy")
        self.rsi_period = rsi_period
        self.overbought = overbought
        self.oversold = oversold
    
    def calculate_indicators(self, data):
        """
        Calculate RSI indicator
        
        Args:
            data (pd.DataFrame): DataFrame with timestamp and price columns
            
        Returns:
            pd.DataFrame: DataFrame with RSI
        """
        if len(data) < self.rsi_period + 1:
            # Not enough data to calculate indicators
            return data
        
        # Copy dataframe to avoid modifying original
        df = data.copy()
        
        # Calculate price changes
        df['price_change'] = df['price'].diff()
        
        # Calculate gains and losses
        df['gain'] = df['price_change'].apply(lambda x: x if x > 0 else 0)
        df['loss'] = df['price_change'].apply(lambda x: -x if x < 0 else 0)
        
        # Calculate average gains and losses
        df['avg_gain'] = df['gain'].rolling(window=self.rsi_period).mean()
        df['avg_loss'] = df['loss'].rolling(window=self.rsi_period).mean()
        
        # Calculate relative strength
        df['rs'] = df['avg_gain'] / df['avg_loss']
        
        # Calculate RSI
        df['rsi'] = 100 - (100 / (1 + df['rs']))
        
        return df
    
    def generate_signal(self, data):
        """
        Generate trading signals based on RSI
        
        Args:
            data (pd.DataFrame): DataFrame with timestamp and price columns
            
        Returns:
            int: 1 for buy, -1 for sell, 0 for no action
        """
        if len(data) < self.rsi_period + 1:
            # Not enough data to generate signals
            return 0
        
        # Calculate indicators
        df = self.calculate_indicators(data)
        
        # Check for NaN values
        if df['rsi'].iloc[-1] is None or np.isnan(df['rsi'].iloc[-1]):
            return 0
        
        current_rsi = df['rsi'].iloc[-1]
        
        # Buy signal: RSI crosses below oversold threshold
        if current_rsi < self.oversold:
            return 1
        
        # Sell signal: RSI crosses above overbought threshold
        elif current_rsi > self.overbought:
            return -1
        
        # No signal
        return 0


class MT5Trader:
    """
    Class for executing trades based on signals in MT5
    """
    
    def __init__(self, strategy, data_fetcher, initial_balance=10000.0, trading_fee=0.001, position_size=0.25):
        """
        Initialize the trader
        
        Args:
            strategy: Strategy instance for generating signals
            data_fetcher: DataFetcher instance for getting price data
            initial_balance (float): Initial USD balance
            trading_fee (float): Trading fee as decimal (e.g., 0.001 for 0.1%)
            position_size (float): Position size as decimal (e.g., 0.25 for 25%)
        """
        self.strategy = strategy
        self.data_fetcher = data_fetcher
        self.initial_balance = initial_balance
        self.balance = initial_balance
        self.btc_amount = 0.0
        self.trading_fee = trading_fee
        self.position_size = position_size
        self.trades = []
        self.positions = []
        
        # Performance tracking
        self.wins = 0
        self.losses = 0
        self.win_rate = 0.0
        
        # MT5 specific settings
        self.symbol = data_fetcher.symbol
        self.lot_size = 0.01  # Default lot size
        
        # Check if MetaTrader 5 is connected
        if not mt5.initialize():
            print("MetaTrader5 initialization failed")
            mt5.shutdown()
            exit(1)
        
        # Enable auto trading
        mt5.terminal_info()
    
    def generate_signal(self, data):
        """
        Generate trading signal using the strategy
        
        Args:
            data (pd.DataFrame): DataFrame with price data
            
        Returns:
            int: Signal (1 for buy, -1 for sell, 0 for no action)
        """
        return self.strategy.generate_signal(data)
    
    def execute_trade(self, signal, price, timestamp):
        """
        Execute a trade based on the signal in MT5
        
        Args:
            signal (int): Signal (1 for buy, -1 for sell)
            price (float): Current price
            timestamp (datetime): Timestamp of the trade
            
        Returns:
            bool: True if trade was executed successfully
        """
        if signal == 0:
            return False
        
        # Buy signal
        if signal > 0:
            return self._execute_buy(price, timestamp)
        
        # Sell signal
        elif signal < 0:
            return self._execute_sell(price, timestamp)
    
    def _execute_buy(self, price, timestamp):
        """
        Execute a buy order in MT5
        
        Args:
            price (float): Current price
            timestamp (datetime): Timestamp of the trade
            
        Returns:
            bool: True if trade was executed successfully
        """
        # Calculate amount to buy
        usd_to_spend = self.balance * self.position_size
        
        # Check if we have enough balance
        if usd_to_spend <= 0:
            return False
        
        # Calculate BTC amount (including fee)
        btc_to_buy = (usd_to_spend * (1 - self.trading_fee)) / price
        
        # Calculate lot size based on amount
        lots = self.lot_size
        
        # Prepare the trade request
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": self.symbol,
            "volume": lots,
            "type": mt5.ORDER_TYPE_BUY,
            "price": price,
            "deviation": 20,  # Maximum price deviation in points
            "magic": 234000,  # MagicNumber to identify this EA's trades
            "comment": "BTC/USD Bot Buy",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        # Send the trade order
        result = mt5.order_send(request)
        
        # Check if the order was successful
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            print(f"Buy order failed, retcode: {result.retcode}")
            return False
        
        # Update balances
        self.balance -= usd_to_spend
        self.btc_amount += btc_to_buy
        
        # Record the trade
        trade = {
            'timestamp': timestamp,
            'type': 'buy',
            'price': price,
            'usd_amount': usd_to_spend,
            'btc_amount': btc_to_buy,
            'fee': usd_to_spend * self.trading_fee,
            'mt5_ticket': result.order  # MT5 order ticket
        }
        self.trades.append(trade)
        
        # Add to positions
        position = {
            'entry_timestamp': timestamp,
            'entry_price': price,
            'btc_amount': btc_to_buy,
            'usd_invested': usd_to_spend,
            'exit_timestamp': None,
            'exit_price': None,
            'usd_returned': None,
            'profit_loss': None,
            'roi': None,
            'mt5_ticket': result.order
        }
        self.positions.append(position)
        
        print(f"Buy order executed: {btc_to_buy:.8f} BTC at ${price:.2f}")
        return True
    
    def _execute_sell(self, price, timestamp):
        """
        Execute a sell order in MT5
        
        Args:
            price (float): Current price
            timestamp (datetime): Timestamp of the trade
            
        Returns:
            bool: True if trade was executed successfully
        """
        # Calculate amount to sell
        btc_to_sell = self.btc_amount * self.position_size
        
        # Check if we have BTC to sell
        if btc_to_sell <= 0:
            return False
        
        # Calculate lot size
        lots = self.lot_size
        
        # Prepare the trade request
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": self.symbol,
            "volume": lots,
            "type": mt5.ORDER_TYPE_SELL,
            "price": price,
            "deviation": 20,  # Maximum price deviation in points
            "magic": 234000,  # MagicNumber to identify this EA's trades
            "comment": "BTC/USD Bot Sell",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        # Send the trade order
        result = mt5.order_send(request)
        
        # Check if the order was successful
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            print(f"Sell order failed, retcode: {result.retcode}")
            return False
        
        # Calculate USD received (including fee)
        usd_received = btc_to_sell * price * (1 - self.trading_fee)
        
        # Update balances
        self.balance += usd_received
        self.btc_amount -= btc_to_sell
        
        # Record the trade
        trade = {
            'timestamp': timestamp,
            'type': 'sell',
            'price': price,
            'usd_amount': usd_received,
            'btc_amount': btc_to_sell,
            'fee': btc_to_sell * price * self.trading_fee,
            'mt5_ticket': result.order
        }
        self.trades.append(trade)
        
        # Update position if we have open positions
        if len(self.positions) > 0:
            # Find oldest open position
            for i, pos in enumerate(self.positions):
                if pos['exit_timestamp'] is None:
                    # Calculate profit/loss for this position
                    pos['exit_timestamp'] = timestamp
                    pos['exit_price'] = price
                    pos['usd_returned'] = (pos['btc_amount'] * price) * (1 - self.trading_fee)
                    pos['profit_loss'] = pos['usd_returned'] - pos['usd_invested']
                    pos['roi'] = (pos['usd_returned'] / pos['usd_invested']) - 1
                    
                    # Update win/loss counters
                    if pos['profit_loss'] > 0:
                        self.wins += 1
                    else:
                        self.losses += 1
                    
                    # Update win rate
                    total_trades = self.wins + self.losses
                    self.win_rate = self.wins / total_trades if total_trades > 0 else 0
                    
                    # For simplicity, only update one position per sell
                    break
        
        print(f"Sell order executed: {btc_to_sell:.8f} BTC at ${price:.2f}")
        return True
    
    def calculate_portfolio_value(self, current_price):
        """
        Calculate the total portfolio value
        
        Args:
            current_price (float): Current BTC price
            
        Returns:
            float: Total portfolio value in USD
        """
        btc_value = self.btc_amount * current_price
        return self.balance + btc_value


class PerformanceTracker:
    """
    Class for tracking trading performance metrics
    """
    
    def __init__(self, initial_balance=10000.0):
        """
        Initialize the performance tracker
        
        Args:
            initial_balance (float): Initial portfolio balance
        """
        self.initial_balance = initial_balance
        self.current_balance = initial_balance
        self.peak_balance = initial_balance
        self.max_drawdown = 0.0
        self.returns = []
        self.balances = []
        self.timestamps = []
    
    def update(self, current_balance, timestamp):
        """
        Update performance metrics with new balance
        
        Args:
            current_balance (float): Current portfolio balance
            timestamp (datetime): Timestamp of the update
        """
        # Update current balance
        self.current_balance = current_balance
        
        # Update peak balance if current balance is higher
        if current_balance > self.peak_balance:
            self.peak_balance = current_balance
        
        # Calculate drawdown
        current_drawdown = 0.0
        if self.peak_balance > 0:
            current_drawdown = (self.peak_balance - current_balance) / self.peak_balance
        
        # Update maximum drawdown
        if current_drawdown > self.max_drawdown:
            self.max_drawdown = current_drawdown
        
        # Calculate return since last update
        if len(self.balances) > 0:
            ret = (current_balance / self.balances[-1]) - 1
            self.returns.append(ret)
        else:
            # First update
            ret = (current_balance / self.initial_balance) - 1
            self.returns.append(ret)
        
        # Store balance and timestamp
        self.balances.append(current_balance)
        self.timestamps.append(timestamp)
    
    def get_performance_summary(self):
        """
        Get a summary of performance metrics
        
        Returns:
            dict: Performance metrics
        """
        total_return = (self.current_balance / self.initial_balance) - 1
        
        # Calculate Sharpe ratio
        sharpe_ratio = 0.0
        if len(self.returns) > 1:
            mean_return = np.mean(self.returns)
            std_dev = np.std(self.returns)
            if std_dev > 0:
                sharpe_ratio = (mean_return / std_dev) * np.sqrt(252)  # Annualized
        
        return {
            'initial_balance': self.initial_balance,
            'current_balance': self.current_balance,
            'total_return': total_return,
            'total_return_pct': total_return * 100,
            'max_drawdown': self.max_drawdown,
            'max_drawdown_pct': self.max_drawdown * 100,
            'sharpe_ratio': sharpe_ratio
        }


def save_results(trader, performance_tracker, filename='mt5_bot_results.json'):
    """
    Save trading results to a file
    
    Args:
        trader: Trader instance
        performance_tracker: PerformanceTracker instance
        filename: Output filename
    """
    try:
        # Prepare data to save
        data = {
            'trades': [],
            'positions': [],
            'performance': performance_tracker.get_performance_summary()
        }
        
        # Convert trades to serializable format
        for trade in trader.trades:
            serializable_trade = {**trade}
            if isinstance(trade['timestamp'], datetime):
                serializable_trade['timestamp'] = trade['timestamp'].isoformat()
            data['trades'].append(serializable_trade)
        
        # Convert positions to serializable format
        for pos in trader.positions:
            serializable_pos = {**pos}
            if isinstance(pos['entry_timestamp'], datetime):
                serializable_pos['entry_timestamp'] = pos['entry_timestamp'].isoformat()
            if pos['exit_timestamp'] is not None and isinstance(pos['exit_timestamp'], datetime):
                serializable_pos['exit_timestamp'] = pos['exit_timestamp'].isoformat()
            data['positions'].append(serializable_pos)
        
        # Save to file
        with open(filename, 'w') as f:
            json.dump(data, f, indent=4)
        
        print(f"Results saved to {filename}")
        return True
    
    except Exception as e:
        print(f"Error saving results: {str(e)}")
        return False


def main():
    """Main function to run the bot"""
    print("BTC/USD Trading Bot for MetaTrader 5")
    print("------------------------------------")
    
    # Configuration
    symbol = "BTCUSD"
    initial_balance = 10000.0
    trading_fee = 0.001  # 0.1%
    position_size = 0.25  # 25%
    update_interval = 60  # seconds
    
    # Using Moving Average Crossover Strategy
    short_window = 20
    long_window = 50
    
    # Initialize components
    data_fetcher = DataFetcher(symbol=symbol)
    strategy = MovingAverageCrossoverStrategy(
        short_window=short_window,
        long_window=long_window
    )
    
    trader = MT5Trader(
        strategy=strategy,
        data_fetcher=data_fetcher,
        initial_balance=initial_balance,
        trading_fee=trading_fee,
        position_size=position_size
    )
    
    performance_tracker = PerformanceTracker(initial_balance=initial_balance)
    
    # Print configuration
    print(f"Symbol: {symbol}")
    print(f"Strategy: {strategy.name}")
    print(f"Short window: {short_window}")
    print(f"Long window: {long_window}")
    print(f"Initial balance: ${initial_balance:.2f}")
    print(f"Position size: {position_size*100:.0f}%")
    print(f"Update interval: {update_interval} seconds")
    print("------------------------------------")
    
    try:
        # Main loop
        running = True
        print("Bot started. Press Ctrl+C to stop.")
        
        while running:
            try:
                # Get current price
                price = data_fetcher.get_current_price()
                if price is None:
                    print("Error getting current price. Skipping this update.")
                    time.sleep(update_interval)
                    continue
                
                timestamp = datetime.now()
                print(f"{timestamp} - Current price: ${price:.2f}")
                
                # Get historical data for signal generation
                historical_data = data_fetcher.get_historical_data(days=30, interval='1h')
                
                # Generate signal
                signal = trader.generate_signal(historical_data)
                
                signal_type = "NONE"
                if signal > 0:
                    signal_type = "BUY"
                elif signal < 0:
                    signal_type = "SELL"
                
                print(f"Signal: {signal_type}")
                
                # Execute trade if signal is not 0
                if signal != 0:
                    trade_result = trader.execute_trade(signal, price, timestamp)
                    if not trade_result:
                        print("Trade execution failed")
                
                # Update performance metrics
                portfolio_value = trader.calculate_portfolio_value(price)
                performance_tracker.update(portfolio_value, timestamp)
                
                # Print portfolio value
                print(f"Portfolio value: ${portfolio_value:.2f}")
                
                # Save results periodically
                save_results(trader, performance_tracker)
                
                # Wait for next update
                time.sleep(update_interval)
            
            except KeyboardInterrupt:
                running = False
                print("Bot stopped by user")
            except Exception as e:
                print(f"Error in main loop: {str(e)}")
                time.sleep(update_interval)
    
    finally:
        # Clean up
        mt5.shutdown()
        
        # Save final results
        save_results(trader, performance_tracker)
        
        # Print summary
        print("\nTrading Summary:")
        print("------------------------------------")
        perf = performance_tracker.get_performance_summary()
        
        print(f"Initial Balance: ${perf['initial_balance']:.2f}")
        print(f"Final Balance: ${perf['current_balance']:.2f}")
        print(f"Total Return: {perf['total_return_pct']:.2f}%")
        print(f"Maximum Drawdown: {perf['max_drawdown_pct']:.2f}%")
        print(f"Sharpe Ratio: {perf['sharpe_ratio']:.2f}")
        
        total_trades = trader.wins + trader.losses
        if total_trades > 0:
            win_rate = (trader.wins / total_trades) * 100
            print(f"Win Rate: {win_rate:.2f}% ({trader.wins}/{total_trades})")


if __name__ == "__main__":
    main()