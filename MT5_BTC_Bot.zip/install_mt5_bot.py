#!/usr/bin/env python
"""
BTC/USD Trading Bot Installer for MetaTrader 5
This script helps install the required dependencies and sets up the bot for MT5
"""

import os
import sys
import subprocess
import shutil
import zipfile
import json

def print_header():
    """Print the installer header"""
    print("\n" + "="*70)
    print(" "*20 + "BTC/USD TRADING BOT INSTALLER")
    print(" "*20 + "For MetaTrader 5")
    print("="*70)
    print("\nThis installer will help you set up the BTC/USD trading bot for MetaTrader 5.")

def check_python_version():
    """Check Python version"""
    print("\nChecking Python version...")
    
    major = sys.version_info.major
    minor = sys.version_info.minor
    
    if major < 3 or (major == 3 and minor < 7):
        print("❌ Error: Python 3.7 or higher is required.")
        print(f"   You are using Python {major}.{minor}.")
        print("   Please install a newer version of Python and try again.")
        return False
    
    print(f"✅ Python {major}.{minor} detected - OK")
    return True

def install_dependencies():
    """Install required dependencies"""
    print("\nInstalling required dependencies...")
    
    dependencies = [
        "MetaTrader5",
        "pandas",
        "numpy"
    ]
    
    for dep in dependencies:
        print(f"Installing {dep}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
            print(f"✅ {dep} installed successfully")
        except subprocess.CalledProcessError as e:
            print(f"❌ Error installing {dep}: {e}")
            return False
    
    print("\n✅ All dependencies installed successfully")
    return True

def install_bot_files():
    """Install bot files to the MT5 Scripts directory"""
    print("\nInstalling bot files...")
    
    # Get the MT5 scripts directory
    print("Please specify the location of your MetaTrader 5 installation:")
    print("Example: C:\\Program Files\\MetaTrader 5")
    
    mt5_directory = input("MetaTrader 5 directory: ").strip()
    
    if not os.path.exists(mt5_directory):
        print(f"❌ Error: Directory {mt5_directory} does not exist.")
        return False
    
    # Create the MQL5/Scripts directory if it doesn't exist
    scripts_directory = os.path.join(mt5_directory, "MQL5", "Scripts", "BTC_USD_Bot")
    experts_directory = os.path.join(mt5_directory, "MQL5", "Experts", "BTC_USD_Bot")
    
    os.makedirs(scripts_directory, exist_ok=True)
    os.makedirs(experts_directory, exist_ok=True)
    
    # Copy the bot files
    try:
        shutil.copy2("mt5_btc_trader.py", os.path.join(scripts_directory, "mt5_btc_trader.py"))
        
        # Create a simple launcher MQL5 script
        with open(os.path.join(scripts_directory, "BTC_USD_Bot_Launcher.mq5"), "w") as f:
            f.write("""//+------------------------------------------------------------------+
//|                                          BTC_USD_Bot_Launcher.mq5 |
//|                                   Copyright 2025, Trading Bot Dev |
//|                                                                   |
//+------------------------------------------------------------------+
#property copyright "Copyright 2025, Trading Bot Dev"
#property link      ""
#property version   "1.00"
#property script_show_inputs

//--- input parameters
input string      PythonPath="C:\\\\Python310\\\\python.exe";  // Path to Python interpreter
input string      BotScript="mt5_btc_trader.py";               // Bot script filename

//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+
void OnStart()
{
   // Display information
   Print("Launching BTC/USD Trading Bot...");
   
   // Get the MQL5 directory
   string terminal_path = TerminalInfoString(TERMINAL_PATH);
   string scripts_path = terminal_path + "\\\\MQL5\\\\Scripts\\\\BTC_USD_Bot\\\\";
   
   // Build the command to execute the Python script
   string command = "\"" + PythonPath + "\" \"" + scripts_path + BotScript + "\"";
   
   // Execute the command
   Print("Executing: ", command);
   int result = ShellExecute(0, "open", PythonPath, "\"" + scripts_path + BotScript + "\"", "", 1);
   
   if(result <= 32)
   {
      Print("Error launching bot. Error code: ", result);
      MessageBox("Failed to launch the BTC/USD Trading Bot.\\n\\nPlease check the terminal logs for more information.", "Error", MB_ICONERROR);
   }
   else
   {
      Print("Bot launched successfully");
      MessageBox("BTC/USD Trading Bot started successfully.\\n\\nCheck the Python console window for details.", "Success", MB_ICONINFORMATION);
   }
}
""")
        
        print(f"✅ Bot files installed to {scripts_directory}")
        return True
    
    except Exception as e:
        print(f"❌ Error installing bot files: {e}")
        return False

def create_bot_config():
    """Create bot configuration file"""
    print("\nCreating bot configuration...")
    
    config = {
        "bot_settings": {
            "symbol": "BTCUSD",
            "initial_balance": 10000.0,
            "trading_fee": 0.001,
            "position_size": 0.25,
            "update_interval": 60
        },
        "strategy_settings": {
            "type": "MA_Crossover",
            "parameters": {
                "short_window": 20,
                "long_window": 50
            }
        }
    }
    
    # Get the user's documents directory
    documents_dir = os.path.expanduser("~\\Documents")
    bot_dir = os.path.join(documents_dir, "BTC_USD_Bot")
    
    # Create the bot directory if it doesn't exist
    os.makedirs(bot_dir, exist_ok=True)
    
    # Write the configuration file
    try:
        with open(os.path.join(bot_dir, "bot_config.json"), "w") as f:
            json.dump(config, f, indent=4)
        
        print(f"✅ Bot configuration created at {bot_dir}\\bot_config.json")
        return True
    
    except Exception as e:
        print(f"❌ Error creating bot configuration: {e}")
        return False

def create_package():
    """Create a package for easy distribution"""
    print("\nCreating distribution package...")
    
    # Create a temporary directory
    package_dir = os.path.join(os.getcwd(), "BTC_USD_Bot_Package")
    os.makedirs(package_dir, exist_ok=True)
    
    try:
        # Copy the bot files
        shutil.copy2("mt5_btc_trader.py", package_dir)
        shutil.copy2("install_mt5_bot.py", package_dir)
        
        # Create a README.txt file
        with open(os.path.join(package_dir, "README.txt"), "w") as f:
            f.write("""BTC/USD TRADING BOT FOR METATRADER 5
====================================

This package contains the BTC/USD trading bot for MetaTrader 5.

INSTALLATION
------------
1. Make sure you have Python 3.7 or higher installed on your computer.
2. Run the installer script 'install_mt5_bot.py' to set up the bot:
   - Open a command prompt/terminal
   - Navigate to this folder
   - Run: python install_mt5_bot.py
3. Follow the on-screen instructions to complete the setup.

USAGE
-----
Once installed, you can run the bot in two ways:
1. From MetaTrader 5:
   - Open MetaTrader 5
   - Go to Navigator > Scripts
   - Find and run 'BTC_USD_Bot_Launcher'

2. Directly from Python:
   - Open a command prompt/terminal
   - Navigate to the MT5 Scripts folder where the bot was installed
   - Run: python mt5_btc_trader.py

CONFIGURATION
------------
You can configure the bot settings by editing the 'bot_config.json' file,
which can be found in your Documents folder under 'BTC_USD_Bot'.

SUPPORT
-------
For support and more information, please contact the developer.

Copyright (c) 2025
""")
        
        # Create a ZIP file
        zip_filename = "BTC_USD_Bot_Package.zip"
        with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(package_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, package_dir)
                    zipf.write(file_path, arcname)
        
        # Clean up temporary directory
        shutil.rmtree(package_dir)
        
        print(f"✅ Distribution package created: {zip_filename}")
        return True
    
    except Exception as e:
        print(f"❌ Error creating distribution package: {e}")
        return False

def main():
    """Main function"""
    print_header()
    
    # Check if this is being run to create a package
    if len(sys.argv) > 1 and sys.argv[1] == "--create-package":
        create_package()
        return
    
    # Regular installation flow
    if not check_python_version():
        return
    
    print("\nThis installer will:")
    print("1. Install required Python dependencies")
    print("2. Install the bot to your MetaTrader 5 directory")
    print("3. Create a configuration file")
    
    proceed = input("\nDo you want to proceed? (y/n): ").strip().lower()
    if proceed != "y":
        print("\nInstallation cancelled.")
        return
    
    # Install dependencies
    if not install_dependencies():
        print("\n❌ Installation failed at dependencies step.")
        return
    
    # Install bot files
    if not install_bot_files():
        print("\n❌ Installation failed at bot files step.")
        return
    
    # Create bot configuration
    if not create_bot_config():
        print("\n❌ Installation failed at configuration step.")
        return
    
    print("\n" + "="*70)
    print(" "*20 + "INSTALLATION COMPLETE")
    print("="*70)
    print("\nThe BTC/USD Trading Bot has been successfully installed.")
    print("\nTo run the bot:")
    print("1. Open MetaTrader 5")
    print("2. Go to Navigator > Scripts")
    print("3. Find and run 'BTC_USD_Bot_Launcher'")
    print("\nAlternatively, you can run the bot directly from Python.")
    
    print("\nThank you for using the BTC/USD Trading Bot!")

if __name__ == "__main__":
    main()